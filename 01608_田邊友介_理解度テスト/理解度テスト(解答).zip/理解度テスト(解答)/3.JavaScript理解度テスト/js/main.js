console.log("画面起動しました。");
let result = window.confirm("確認ダイアログです");
if (result){
    alert("OKボタンが押下されました");
    const hairetsu = [1,2,3,4,5,6,7,8,9,10];
    for(let i = 0; i < hairetsu.length ; i++){
        console.log(hairetsu[i]);
    }
}else{
    alert("キャンセルボタンが押下されました");
}
const btn = document.querySelector('.btn');
btn.addEventListener('click', () => {
    alert('画像をクリックしました。');
})
